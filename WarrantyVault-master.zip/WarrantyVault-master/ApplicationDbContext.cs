﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using WarrantyVault.Models;

namespace WarrantyVault.Data;

public class ApplicationDbContext : IdentityDbContext
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
        : base(options)
    {
    }

    public DbSet<WarrantyItem> WarrantyItems { get; set; }
    public DbSet<WarrantyDocument> WarrantyDocuments { get; set; }
}