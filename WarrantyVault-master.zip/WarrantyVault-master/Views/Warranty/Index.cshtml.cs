using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WarrantyVault.Views.Warranty
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
