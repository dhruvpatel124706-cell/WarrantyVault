﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WarrantyVault.Data;
using WarrantyVault.Models;

namespace WarrantyVault.Controllers;

[Authorize]
public class WarrantyController : Controller
{
    private readonly ApplicationDbContext _db;
    private readonly UserManager<IdentityUser> _userManager;
    private readonly IWebHostEnvironment _env;
    private static readonly string[] AllowedExt = { ".pdf", ".jpg", ".jpeg", ".png" };

    public WarrantyController(ApplicationDbContext db, UserManager<IdentityUser> userManager, IWebHostEnvironment env)
    {
        _db = db; _userManager = userManager; _env = env;
    }

    private string UserId => _userManager.GetUserId(User)!;

    private string UploadFolder
    {
        get
        {
            var path = Path.Combine(_env.ContentRootPath, "UserUploads");
            Directory.CreateDirectory(path);
            return path;
        }
    }

    // ---------- Dashboard + List + Search ----------
    public async Task<IActionResult> Index(string? search)
    {
        var items = await _db.WarrantyItems.Include(w => w.Documents)
                             .Where(w => w.UserId == UserId).ToListAsync();

        ViewBag.Total = items.Count;
        ViewBag.Active = items.Count(i => i.Status == "Active");
        ViewBag.Soon = items.Count(i => i.Status == "Expiring Soon");
        ViewBag.Expired = items.Count(i => i.Status == "Expired");
        ViewBag.Search = search;

        if (!string.IsNullOrWhiteSpace(search))
            items = items.Where(i => i.Name.Contains(search, StringComparison.OrdinalIgnoreCase)
                                  || (i.Brand ?? "").Contains(search, StringComparison.OrdinalIgnoreCase)).ToList();

        return View(items.OrderBy(i => i.ExpiryDate).ToList());
    }

    // ---------- Create ----------
    public IActionResult Create() => View(new WarrantyItem());

    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(WarrantyItem item, List<IFormFile> files)
    {
        ModelState.Remove(nameof(WarrantyItem.UserId));
        if (!ModelState.IsValid) return View(item);

        item.UserId = UserId;
        _db.WarrantyItems.Add(item);
        await _db.SaveChangesAsync();
        await SaveFiles(item.Id, files);
        return RedirectToAction(nameof(Details), new { id = item.Id });
    }

    // ---------- Details ----------
    public async Task<IActionResult> Details(int id)
    {
        var item = await GetItem(id);
        return item == null ? NotFound() : View(item);
    }

    // ---------- Upload more documents ----------
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Upload(int id, List<IFormFile> files)
    {
        var item = await GetItem(id);
        if (item == null) return NotFound();
        await SaveFiles(id, files);
        return RedirectToAction(nameof(Details), new { id });
    }

    // ---------- Download / View document ----------
    public async Task<IActionResult> Download(int id)
    {
        var doc = await _db.WarrantyDocuments.Include(d => d.WarrantyItem)
                           .FirstOrDefaultAsync(d => d.Id == id && d.WarrantyItem!.UserId == UserId);
        if (doc == null) return NotFound();

        var path = Path.Combine(UploadFolder, doc.StoredFileName);
        if (!System.IO.File.Exists(path)) return NotFound();
        return PhysicalFile(path, doc.ContentType, doc.OriginalFileName);
    }

    // ---------- Delete document ----------
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteDocument(int id)
    {
        var doc = await _db.WarrantyDocuments.Include(d => d.WarrantyItem)
                           .FirstOrDefaultAsync(d => d.Id == id && d.WarrantyItem!.UserId == UserId);
        if (doc == null) return NotFound();

        var path = Path.Combine(UploadFolder, doc.StoredFileName);
        if (System.IO.File.Exists(path)) System.IO.File.Delete(path);

        int itemId = doc.WarrantyItemId;
        _db.WarrantyDocuments.Remove(doc);
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Details), new { id = itemId });
    }

    // ---------- Delete product ----------
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id)
    {
        var item = await GetItem(id);
        if (item == null) return NotFound();

        foreach (var d in item.Documents)
        {
            var path = Path.Combine(UploadFolder, d.StoredFileName);
            if (System.IO.File.Exists(path)) System.IO.File.Delete(path);
        }
        _db.WarrantyItems.Remove(item);
        await _db.SaveChangesAsync();
        return RedirectToAction(nameof(Index));
    }

    // ---------- Helpers ----------
    private Task<WarrantyItem?> GetItem(int id) =>
        _db.WarrantyItems.Include(w => w.Documents)
           .FirstOrDefaultAsync(w => w.Id == id && w.UserId == UserId);

    private async Task SaveFiles(int itemId, List<IFormFile> files)
    {
        foreach (var f in files)
        {
            if (f.Length == 0 || f.Length > 5 * 1024 * 1024) continue; // max 5 MB
            var ext = Path.GetExtension(f.FileName).ToLower();
            if (!AllowedExt.Contains(ext)) continue;                  // sirf pdf/jpg/png

            var stored = Guid.NewGuid() + ext;
            using (var fs = new FileStream(Path.Combine(UploadFolder, stored), FileMode.Create))
                await f.CopyToAsync(fs);

            _db.WarrantyDocuments.Add(new WarrantyDocument
            {
                WarrantyItemId = itemId,
                OriginalFileName = Path.GetFileName(f.FileName),
                StoredFileName = stored,
                ContentType = f.ContentType
            });
        }
        await _db.SaveChangesAsync();
    }
}