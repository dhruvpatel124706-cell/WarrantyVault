﻿namespace WarrantyVault.Models;

public class WarrantyDocument
{
    public int Id { get; set; }
    public int WarrantyItemId { get; set; }
    public WarrantyItem? WarrantyItem { get; set; }
    public string OriginalFileName { get; set; } = "";
    public string StoredFileName { get; set; } = "";
    public string ContentType { get; set; } = "";
    public DateTime UploadedOn { get; set; } = DateTime.Now;
}