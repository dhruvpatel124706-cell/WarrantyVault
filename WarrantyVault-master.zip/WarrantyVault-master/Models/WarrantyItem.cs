﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WarrantyVault.Models;

public class WarrantyItem
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    [Display(Name = "Product Name")]
    public string Name { get; set; } = "";

    [StringLength(100)]
    public string? Brand { get; set; }

    [StringLength(50)]
    public string? Category { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "Purchase Date")]
    public DateTime PurchaseDate { get; set; } = DateTime.Today;

    [Range(1, 240)]
    [Display(Name = "Warranty (months)")]
    public int WarrantyMonths { get; set; } = 12;

    public decimal? Price { get; set; }

    public string? Notes { get; set; }

    public string UserId { get; set; } = "";

    public List<WarrantyDocument> Documents { get; set; } = new();

    [NotMapped] public DateTime ExpiryDate => PurchaseDate.AddMonths(WarrantyMonths);
    [NotMapped] public int DaysLeft => (ExpiryDate.Date - DateTime.Today).Days;
    [NotMapped]
    public string Status =>
        DaysLeft < 0 ? "Expired" : DaysLeft <= 30 ? "Expiring Soon" : "Active";
}